package uk.ac.man.cs.eventlite.controllers;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.validation.Valid;
import uk.ac.man.cs.eventlite.dao.EventService;
import uk.ac.man.cs.eventlite.dao.VenueService;
import uk.ac.man.cs.eventlite.entities.Event;
import uk.ac.man.cs.eventlite.entities.Venue;
import uk.ac.man.cs.eventlite.exceptions.EventNotFoundException;

@Controller
@RequestMapping(value = "/events", produces = { MediaType.TEXT_HTML_VALUE })
public class EventsController {

	@Autowired
	private EventService eventService;
	
	@Autowired
	private VenueService venueService;


	@ExceptionHandler(EventNotFoundException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public String eventNotFoundHandler(EventNotFoundException ex, Model model) {
		model.addAttribute("not_found_id", ex.getId());

		return "events/not_found";
	}

	@GetMapping("/{id}")
	public String getEvent(@PathVariable("id") long id,
			@RequestParam(value = "name", required = false, defaultValue = "World") String name, Model model ) {
		Event event = eventService.findById(id).orElseThrow(() -> new EventNotFoundException(id));
		model.addAttribute("event", event);

		return "events/description";
		
	}

	@GetMapping
	public String getAllEvents(Model model) {
		List<Event> allEvents = (List<Event>) eventService.findAll();
        List<Event> upcomingEvents = new ArrayList<>();
        List<Event> previousEvents = new ArrayList<>();

        LocalDate today = LocalDate.now();
        for (Event event : allEvents) {
            if (event.getDate().isAfter(today)) {
                upcomingEvents.add(event);
            } else {
                previousEvents.add(event);
            }
        }

        model.addAttribute("upcomingEvents", upcomingEvents);
        model.addAttribute("previousEvents", previousEvents);

		return "events/index";
	}
	
	@GetMapping("/venues")
	public String getAllVenues(Model model) {
		List<Venue> allVenues = (List<Venue>) venueService.findAll();

        model.addAttribute("allVenues", allVenues);

		return "events/venues";
	}
	
	@DeleteMapping("/{id}")
	public String deleteEvent(@PathVariable("id") long id) {
		Event event = eventService.findById(id).orElseThrow(() -> new EventNotFoundException(id));
		eventService.delete(event);
		
		return "redirect:/events";
	}
	
	@GetMapping("/new")
	public String newEvent(Model model) {
		if (!model.containsAttribute("event")) {
			model.addAttribute("event", new Event());
		}
		if (!model.containsAttribute("venue")) {
			model.addAttribute("venue", new Venue());
		}

		return "events/new";
	}
	
	@GetMapping("/update/{id}")
	public String updateEvent(@PathVariable("id") long id, Model model) {
		if (!model.containsAttribute("event")) {
			model.addAttribute("event", new Event());
		}
		if (!model.containsAttribute("venue")) {
			model.addAttribute("venue", new Venue());
		}
		Event existingEvent = eventService.findById(id).orElseThrow(() -> new EventNotFoundException(id));
		model.addAttribute("event", existingEvent);

		return "events/update";
	}
	
	@GetMapping("/search")
	public String searchEvent(@RequestParam(value = "search", required = false) String search, Model model) {
		List<Event> searchedEvents = (List<Event>) eventService.findByNameContainingIgnoreCaseOrderByDateAscNameAsc(search);
		List<Event> searchedUpcomingEvents = new ArrayList<>();
        List<Event> searchedPreviousEvents = new ArrayList<>();

        LocalDate today = LocalDate.now();
        for (Event event : searchedEvents) {
            if (event.getDate().isAfter(today)) {
            	searchedUpcomingEvents.add(event);
            } else {
            	searchedPreviousEvents.add(event);
            }
        }

        model.addAttribute("upcomingEvents", searchedUpcomingEvents);
        model.addAttribute("previousEvents", searchedPreviousEvents);
	    return "events/index";
	}

	@PostMapping(consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public String createEvent(@ModelAttribute @Valid  Event event, BindingResult errors,
			Model model, RedirectAttributes redirectAttrs) {

		if (errors.hasErrors()) {
			model.addAttribute("event", event);
			System.out.println(errors);
			return "events/new";
		}
		eventService.save(event);
		redirectAttrs.addFlashAttribute("ok_message", "New event added.");
		return "redirect:/events";
	}

	
	@PostMapping("/update")
	public String updateEvent(@RequestBody @Valid @ModelAttribute Event updatedEvent, BindingResult errors,
	        Model model, RedirectAttributes redirectAttrs) {
	    if (errors.hasErrors()) {
	        model.addAttribute("event", updatedEvent);
	        System.out.println(errors);
	        return "events/update";
	    }

	    Event retrievedEvent = eventService.findById(updatedEvent.getId()).orElseThrow(() -> new EventNotFoundException(updatedEvent.getId()));

	    retrievedEvent.setName(updatedEvent.getName());
	    retrievedEvent.setDate(updatedEvent.getDate());
	    retrievedEvent.setTime(updatedEvent.getTime());
	    retrievedEvent.setVenue(updatedEvent.getVenue());
	    retrievedEvent.setDescription(updatedEvent.getDescription());

	    eventService.save(retrievedEvent);

	    return "redirect:/events";
	}

	@ModelAttribute("venueList")
	public List<Venue> getVenueList() {
		List<Venue> venues = StreamSupport.stream(venueService.findAll().spliterator(), false).collect(Collectors.toList());
		return venues;
	}

}