package uk.ac.man.cs.eventlite.entities;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.NotEmpty;





@Entity
@Table(name = "venue")

public class Venue {

	@Id
	@GeneratedValue
	private long id;

	@NotEmpty(message = "The venue name cannot be empty.")
	private String name;

	private int capacity;
	
	@OneToMany(mappedBy = "venue")
	private List<Event> events;

	public Venue() {
	}
	
	public Venue(long id, String name, int capacity) {
		this.id = id;
		this.name = name;
		this.capacity = capacity;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
}
