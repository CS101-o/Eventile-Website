package uk.ac.man.cs.eventlite.config.data;


import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.cglib.core.Local;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import uk.ac.man.cs.eventlite.dao.EventService;
import uk.ac.man.cs.eventlite.dao.EventServiceImpl;
import uk.ac.man.cs.eventlite.dao.VenueService;
import uk.ac.man.cs.eventlite.entities.Event;
import uk.ac.man.cs.eventlite.entities.Venue;

@Configuration
@Profile("default")
public class InitialDataLoader {

	private final static Logger log = LoggerFactory.getLogger(InitialDataLoader.class);

	@Autowired
	private EventService eventService;

	@Autowired
	private VenueService venueService;
	


	private void eventCreator(int id, String name, LocalDate date, LocalTime time, Venue venue, String description) {
		Event event = new Event();
		event.setId(id);
		event.setName(name);
		event.setDate(date);
		event.setTime(time);
		event.setVenue(venue);
		event.setDescription(description);
		eventService.save(event);
	}


	@Bean
	CommandLineRunner initDatabase() {
		return args -> {
			// Build and save initial venues here.

			Venue v1 = new Venue(1, "Kilburn Building", 120 );
			Venue v2 = new Venue(2, "Online", 100000);
			if (venueService.count() > 0) {
				log.info("Database already populated with venues. Skipping venue initialization.");
			} else {
				venueService.save(v1);
				venueService.save(v2);
			}

			if (eventService.count() > 0) {
				log.info("Database already populated with events. Skipping event initialization.");
			} else {
				eventCreator(1, "COMP23412 Showcase 01", LocalDate.of(2024, 5, 7), LocalTime.of(19, 0), v1, "Description");
        		eventCreator(2, "Scientology Auditing Showcase 01", LocalDate.of(2024, 5, 7), LocalTime.of(12, 0), v2, "Description");
        		eventCreator(3, "Flat Earth Society Meeting", LocalDate.of(2024, 5, 9), LocalTime.of(15, 0), v1, "Description");
        		
				
				
				
				

				
			}
		};
	}
}
