package uk.ac.man.cs.eventlite.dao;

import java.util.Optional;

import uk.ac.man.cs.eventlite.entities.Event;

public interface EventService {

	public long count();

	public Iterable<Event> findAll();
	
	public Event save(Event Event);
	
	public Optional<Event> findById(long id);

	public void deleteAll();
	
	public void delete(Event event);
	
	public Iterable<Event> findByName(String name);
	
	public Iterable<Event> findByNameContainingIgnoreCase(String name);
	
	public Iterable<Event> findByNameContainingIgnoreCaseOrderByDateAscNameAsc(String name);
}
