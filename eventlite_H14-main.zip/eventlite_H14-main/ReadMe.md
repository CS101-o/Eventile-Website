# COMP23412 EventLite
## COMP23412 Software Engineering, University of Manchester, UK
### Robert Haines, Markel Vigo, Mustafa Mustafa, Tom Carroll, Caroline Jay

*This is the skeleton lab code for the team-based exercise.*

See the instructions in Blackboard for more details.

Main Branch.

#### Licence

BSD licenced. See Licence.md.